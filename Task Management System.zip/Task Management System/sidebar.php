<!DOCTYPE html>
<html lang="en">
<head>
  <title>Task Management System</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="assets/js/custom.js"></script>
  <script src="assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script src="assets/bootstrap-datepicker/js/datepicker-custom.js"></script>
  <script type="text/javascript">
  // <link rel = "stylesheet" type="text/css" href = "https://netdna.bootstrapcdbn.com/font-awesome/4.0.3/css/font-awesome.css" rel = "stylesheet">
  // <meta name = "viewport" content="width=device-width, initial-scale=1">
    
    function check_delete() {
      var check = confirm('Are you sure you want to delete this?');
        if (check) {
         
            return true;
        } else {
            return false;
      }
    }
  </script>


<style>
ul {
  display: inline;
  overflow: auto;
  /* length : 100%; */
  list-style-type: none;
  margin: 14%;
padding: 15px;
  /* width: 100px; */
  background-color: #f1f1f1;
  white-space: nowrap;
}
li {
  display: inline;
  width: 100px;
 
}
li a {
  display: inline;
  color: #000;
  padding:16px;
    width: 100px;
  text-decoration: none;
}

/* Change the link color on hover */
li a:hover {
  background-color: #555;
  color: white;
}
</style>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style = "inline" style="margin:70px"></nav>
    <div class="container-fluid">

      

    <div class="navbar-header">
       <class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
        <!-- <span class="sr-only">Toggle navigation</span> -->
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>
    <div style="margin-top:0px">


</div>
    <?php
    $user_role = $_SESSION['user_role'];
     if($user_role == 1){
    ?>
      
    <div class="collapse navbar-collapses" id="bs-sidebar-navbar-collapse-1" border = "1" style="margin:20px">
      <tr><ul class="nav navbar-nav navbar-nav-custom">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li <?php if($page_name == "Task_Info" ){echo "class=\"active\"";} ?>><a href="task-info.php"><i class="fa fa-bar-chart-o" aria-hidden="true">&nbsp;</i><span class="nav-text">Task Mangement</span></a></li> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li <?php if($page_name == "Attendance" ){echo "class=\"active\"";} ?>><a href="attendance-info.php"><i class="fa fa-calendar" aria-hidden="true">&nbsp;</i>Attendance <span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-calendar"></span></a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <!-- <li ?php if($page_name == "Admin" ){echo "class=\"active\"";} ><a href="manage-admin.php">User<span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-user"></span></a></li> -->
        <li class="active"><a href="manage-admin.php"><i class="fa fa-users" aria-hidden="true">&nbsp;</i>Manage Admin</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <li><a href="admin-manage-user.php"><i class="fa fa-info-circle" aria-hidden="true">&nbsp;</i>Manage Student</a></li> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li ><a href="?logout=logout"><i class="fa fa-circle-o" aria-hidden="true">&nbsp;</i>Logout<span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-log-out"></span></a></li>
      </ul></tr>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
    
    </div>
    <Center><a class="navbar-brand" href="task-info.php"><span style="color: #d4ab3a; font-weight: bold;"><h1>DASHBOARD</h1></span></a></center>
    <!-- <h2 class="center-block"> Welcome<span>
 php echo $user_name; </span> </h2> -->
    <?php 
     }else if($user_role == 2){

      ?>
    <div class="collapse navbar-collapses" id="bs-sidebar-navbar-collapse-1" border = "1" style="margin:50px">
      <tr><ul class="nav navbar-nav navbar-nav-custom">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li <?php if($page_name == "Task_Info" ){echo "class=\"active\"";} ?>><a href="task-info.php"><i class="fa fa-bar-chart-o" aria-hidden="true">&nbsp;</i>Task Mangement<span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-tasks" ></span></a></li> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li <?php if($page_name == "Attendance" ){echo "class=\"active\"";} ?>><a href="attendance-info.php"><i class="fa fa-calendar" aria-hidden="true">&nbsp;</i>Attendance <span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-calendar"></span></a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <!-- <li ?php if($page_name == "Admin" ){echo "class=\"active\"";} ><a href="manage-admin.php">User<span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-user"></span></a></li> -->
        <!-- <li class="active"><a href="manage-admin.php">Manage Admin</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -->
        <li><a href="admin-manage-user.php"><i class="fa fa-info-circle" aria-hidden="true">&nbsp;</i>Manage Student</a></li> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li ><a href="?logout=logout"><i class="fa fa-circle-o" aria-hidden="true">&nbsp;</i>Logout<span style="font-size:16px; color:#d4ab3a;" class="pull-right hidden-xs showopacity glyphicon glyphicon-log-out"></span></a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </ul></tr>
    </div>
    <Center><a class="navbar-brand" href="task-info.php"><span style="color: #d4ab3a; font-weight: bold;"><h1>DASHBOARD</h1></span></a></center>

      <?php

     }else{
       header('Location: index.php');
     }

    ?>
    


  </div>




<div class="main">