<?php 
require 'authentication.php'; 
    
    $name = $_SESSION['name'];
    
    if ($name != NULL) {
        
      header('Location: task-info.php');
    }
// echo"exit(0)";

if(isset($_REQUEST["submit"]))
{
    
	$file=$_FILES["file"]["name"];
	$tmp_name=$_FILES["file"]["tmp_name"];
	$path="Include/uploads/".$file;
	$file1=explode(".",$file);
	$ext=$file1[1];
	$allowed=array("jpg","png","gif","pdf","wmv","pdf","zip");
	if(in_array($ext,$allowed))
	{
 move_uploaded_file($tmp_name,$path);
 	
 $sql1 ="INSERT INTO store(name, file) VALUES('$name', '$file')";

}
}
if ($conn->query($sql1) === TRUE) {
 header ("task-info.php");
//      echo "New record created successfully";
   } else {
   echo "Error: " . $sql1 . "<br>" . $conn->error;
  }
?>