<?php
require 'authentication.php'; 
// require_once 'admin_class.php';


$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$user_role = $_SESSION['user_role'];


if(isset($_GET['delete_task'])){
  $action_id = $_GET['task_id'];
  
  $sql = "UPDATE task_info set t_status = 0 WHERE task_id = :id";
  $sent_po = "task-info.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}

if(isset($_POST['add_task_post'])){
    $obj_admin->add_new_task($_POST);
}


$page_name="Task_Info";
include("sidebar.php");
include('ems_header.php');

 
?>




    <div class="row">
      <div class="col-md-12"><br>
        <div class="well well-custom">
          <div class="gap"></div>
          <div class="row">
            <div class="col-md-8">  
              <div class="btn-group">
                

    <div class="navbar-header">
                <?php if($user_role == 1){ ?>
                <div class="btn-group">
                <a href = "assign-task.php"> <button class="btn btn-warning btn-menu" data-toggle="modal" data-target="#myModal" style = "background-color:grey;">Assign New Task</button></a>
                </div>


                <!-- <div class="btn-group">
                <a href = "pdf.php"> <button class="btn btn-warning btn-menu" data-toggle="modal" data-target="#myModal">pdf</button></a>
                </div> -->


              <?php } ?>

              </div>

            </div>

            
          </div>
          <center ><h3>Task Management Section</h3></center>
          <div class="gap"></div>

          <div class="gap"></div>

          <div class="table-responsive">
            <center><table class="table table-codensed table-custom" border = "1" align = "center"style="width:73%">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Task Title</th>
                  <th>Assigned To</th>
                  <th>Start Time</th>
                  <th>End Time</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>


              </thead>
              <tbody>

              <?php 

                // include("dbconnection.php");

                $sql1 ="SELECT COUNT(*) as total FROM task_info";
                $count = $conn->query($sql1);
                $row = $count->fetch_assoc();

                $page = 0;
                $size = 5;
                $totalpage = ceil($row['total']/$size);
                if(isset($_POST['pg']))
                {
                  $page = ($_POST['pg']-1)*$size;
                }


                $sql = "SELECT * FROM task_info WHERE status = 2 ORDER BY task_id DESC LIMIT $page,$size";

                if($user_role == 1){
                  $sql = "SELECT a.*, b.fullname 
                        FROM task_info a
                        INNER JOIN tbl_admin b ON(a.t_user_id = b.user_id) and t_status = 1
                        ORDER BY a.task_id DESC LIMIT $page,$size";
                }else{
                  $sql = "SELECT a.*, b.fullname 
                  FROM task_info a
                  INNER JOIN tbl_admin b ON(a.t_user_id = b.user_id) and t_status = 1
                  WHERE a.t_user_id = $user_id
                  ORDER BY a.task_id DESC LIMIT $page,$size";
                } 
                
                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="7">No Data found</td></tr>';
                  }
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['t_title']; ?></td>
                  <td><?php echo $row['fullname']; ?></td>
                  <td><?php echo $row['t_start_time']; ?></td>
                  <td><?php echo $row['t_end_time']; ?></td>
                  <td>
                    <?php  if($row['status'] == 1){
                        echo "In Progress <span style='color:#d4ab3a;' class=' glyphicon glyphicon-refresh' >";
                    }elseif($row['status'] == 2){
                       echo "Completed <span style='color:#00af16;' class=' glyphicon glyphicon-ok' >";
                    }else{
                      echo "Incomplete <span style='color:#d00909;' class=' glyphicon glyphicon-remove' >";
                    } ?>
                    
                  </td>
  
                 <td>
                   
                 
                 
                 <!-- <form method="post" role="form" enctype="multipart/form-data"> 
                  <input type="file" name="pdf_file" id="pdf_file" accept="application/pdf" />
                  <button id="send" type="submit" name="submit" class="btn btn-success" style = "background-color:gray;" >Submit</button>
                </form><br> -->
                <form action = "upload.php" enctype="multipart/form-data" method="post">
                <input type="file" name="file"style = "background-color:skyblue;">
                <input type="submit" name="submit" value="SUBMIT" style = "background-color:gray;">
                </form>           <br>      
                              

              
                 
                 <a title="Update Task"  href="edit-task.php?task_id=<?php echo $row['task_id'];?>"><span class="glyphicon glyphicon-edit"><button style = "background-color:yellow;">UPDATE</button></span></a>&nbsp;&nbsp;
                  <a title="View" href="task-details.php?task_id=<?php echo $row['task_id']; ?>"><span class="glyphicon glyphicon-folder-open"><button style = "background-color:lightgreen;">DETAILS</button></span></a>&nbsp;&nbsp;
                  <?php if($user_role == 1){ ?>
                  <a title="Delete" href="?delete_task=delete_task&task_id=<?php echo $row['task_id']; ?>" onclick=" return check_delete();"><span class="glyphicon glyphicon-trash"><button style = "background-color:red;">DELETE</button></span></a>
                  <!-- <?php $link ="http://localhost/Task Management System/Include/uploads/".htmlentities(rawurlencode($name)); ?>
                                        <td><a href= <?php echo $link; ?> target = _blank>Download</a></td> -->



                <?php } ?>


                
                </tr>
                <?php } ?>
                
              </tbody>
                  </center>
            </table>
          </div>
        </div>
      </div>
    </div>


<?php



echo "<center><table border=0><tr>";
for($i=1;$i<=$totalpage;$i++){
  echo "<td>
    <form method='post' action='./task-info.php'>
      <input type='hidden' value=$i name='pg'></input>
      <input type='submit' name='submit' value='$i'>
    </form>
  </td>";
}
echo "<tr></table></center>";

?>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script type="text/javascript">
  flatpickr('#t_start_time', {
    enableTime: true
  });

  flatpickr('#t_end_time', {
    enableTime: true
  });

</script>
<style>
body {

  
  background-image: url("./CSS/img/2.jpg");


  
    background-size: cover;
    
    
    
    height: 100vh;
    padding:0;
    margin:0;

}
img {
  opacity: 0.2;
}
</style>
<?php
include('footer.php');
?>