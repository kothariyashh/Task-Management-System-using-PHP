$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker2").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker3").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker4").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});