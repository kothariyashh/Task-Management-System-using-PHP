
				<div class="copy_right mx-md-auto mb-md-0 mb-3" align = "right"><br>
					<p class="text-bl let">© All rights reserved | Design by <B>YASH KOTHARI</B>&nbsp;&nbsp;
					</p>
				</div><br>
