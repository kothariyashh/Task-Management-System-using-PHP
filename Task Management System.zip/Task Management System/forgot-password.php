<?php 
    // require_once('connect.php');
    session_start();
    $server = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tms";
    $ran = random_int(2355,7676);
    $_SESSION['ran'] = $ran;

    $conn = mysqli_connect($server, $username, $password, $dbname);
  
    

    require_once ('./Include/PHPMailer.php');
    require_once ('./Include/SMTP.php');
    
    // echo gettype($_SESSION['otp']) . "<br>";
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $_SESSION['otp'] = $_SESSION['ran'];

        if(isset($_POST['otp'], $_POST['newpassword'], $_POST['new2password'])){

            echo ' ' . $_POST['otp'] . ' ' . $_POST['newpassword'] . ' ' . $_POST['new2password'];
            $x = intval($_POST['otp']);
            echo gettype($x);

            if($_SESSION['otp'] == $x && $_POST['newpassword'] == $_POST['new2password']){
                echo 'same';
                $sql = "UPDATE account SET password = '" . $_POST['newpassword'] . "' WHERE name = '" . $_SESSION['name'] . "'";
                echo $sql;
                if(mysqli_query($conn, $sql)){
                    // echo '<br>' . 'success';
                    header('Location: index.php');
                }
                // else{
                //     echo mysqli_connect_error
                // }
                
            }
            else if($_SESSION['otp'] != $_POST['otp']){
                echo 'wrong otp or it is ' . gettype($x);
            }
            else if($_POST['newpassword'] != $_POST['new2password']){
                echo 'password did not match';
            }


        }


    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>forgot password</h3>

    <?php
        if(!isset($_POST['name'])){

            ?>

            <form action="forgot-password.php" method='POST'>
                    <label for="name">User name</label> <br>
                    <input type="text" name="name"> <br><br>
                    <label for="e-mail">Email address</label> <br>
                    <input type="email" name="e-mail" require> <br><br>
                    <button value='submit'>get OTP</button>
                </form>

            <?php
            $_SESSION['ran'] = $ran;

            
        }

    ?>

    <?php
        if(isset($_POST['name']) && isset($_POST['e-mail'])){
            $_SESSION['name'] = $_POST['name'];
            $_SESSION['email'] = $_POST['e-mail'];
            echo $_SESSION['ran'];


            // this is the email part

            $mail = new PHPMailer(true);

            //Enable SMTP debugging.
            $mail->SMTPDebug = 3;                               
            //Set PHPMailer to use SMTP.
            $mail->isSMTP();            
            //Set SMTP host name                          
            $mail->Host = "smtp.gmail.com";
            //Set this to true if SMTP host requires authentication to send email
            $mail->SMTPAuth = true;                          
            //Provide username and password     
            $mail->Username = "kothariyash360@gmail.com";                 
            $mail->Password = "yashk711";                           
            //If SMTP requires TLS encryption then set it
            $mail->SMTPSecure = "tls";                           
            //Set TCP port to connect to
            $mail->Port = 587;                                   

            $mail->From = "kothariyash360@gmail.com";
            $mail->FromName = "It is the admin of the server";

            $mail->addAddress($_POST['e-mail'], "My EMail");

            $mail->isHTML(true);

            $mail->Subject = "this is to test the communicatin";
            $mail->Body = "<h3 style='color:red;'>Forgot password</h3>
            <p>your OTP is " . $_SESSION['ran'] . " keep this as a sectret. Do not share</p>";
            $mail->AltBody = "This is the plain text version of the email content";

            try {
                $mail->send();
                echo "Message has been sent successfully";
                
            } catch (Exception $e) {
                echo "Mailer Error: " . $mail->ErrorInfo;
            }
            // echo 'hi';
            
       ?>
    <form action="forgot-password.php" method='POST'>
<input type="text" placeholder='username' name='otp'><br><br>
        <input type="text" placeholder='OTP' name='otp'> <br><br>
        <input type="text" placeholder='new password' name='newpassword' ><br><br>
        <input type="text" placeholder='re-enter password' name='new2password' ><br><br>
        <a href = "index.php"><input type="submit"><br><a>
    </form>

    <?php 
    }
    
    ?>
    
</body>
</html>