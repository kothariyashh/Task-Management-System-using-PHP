<?php 

ob_start();
session_start();
require 'admin_class.php';
$obj_admin = new Admin_Class();

if(isset($_GET['logout'])){
	$obj_admin->admin_logout();
}

$servername='localhost';
$user_name='root';
$password='';
$db_name='tms';


$conn = new mysqli($servername, $user_name, $password, $db_name);


$conn1 = mysqli_connect('localhost', 'root', '',"tms") or die("Database Connection failed.");


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// session_start();
$ran = random_int(000000,999999);

?>
