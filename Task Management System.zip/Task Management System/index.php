<?php
require 'authentication.php'; 


if(isset($_SESSION['admin_id'])){
  $user_id = $_SESSION['admin_id'];
  $user_name = $_SESSION['admin_name'];
  $security_key = $_SESSION['security_key'];
  if ($user_id != NULL && $security_key != NULL) {
    header('Location: task-info.php');
  }
}

if(isset($_POST['login_btn'])){
 $info = $obj_admin->admin_login_check($_POST);
}

$page_name="Login";
include("login_header.php");

?>
<table border = "1" >
<div class="row">
<center>
	<div class="col-md-4 col-md-offset-3">
		<div class="well" style="position:relative;top:20vh;">
		<center><h2 class="text-center"  style = "color:white;"> Task Management System</h2></center>
			<form class="form-horizontal form-custom-login" action="" method="POST">
			  <div class="form-heading">
			    <h2 class="text-center" style = "color:white;">Login Here</h2>
			  </div>
			  
			  
			  <?php if(isset($info)){ ?>
			  <h5 class="alert alert-danger" ><?php echo $info; ?></h5>
			  <?php } ?>
			  
			  <div class="form-group">
			    <input type="text" class="form-control" placeholder="Username" name="username" required/>
			  </div>
			  <div class="form-group" ng-class="{'has-error': loginForm.password.$invalid && loginForm.password.$dirty, 'has-success': loginForm.password.$valid}"><br>
			    <input type="password" class="form-control" placeholder="Password" name="admin_password" required/><br>
			  </div>
			  <br>
			  <button type="submit" name="login_btn" class="btn btn-info pull-right" style = "background-color:grey;">Login</button><br>

			</form><br>
			<button style = "background-color:gray;"><a href="./forgot-password.php">forget password</a></button>
			<!-- <button type="submit" name="login_btn" class="btn btn-info pull-right"><a href="./reset_password_INC.php" traget="_blank"align = "center">forgot password</a></button> -->
		</div>
		</center>
	</div>
</div>
</table>

<style>
body {

    background-image: url('http://i.stack.imgur.com/kx8MT.gif');
    background-size: cover;
    
    
    
    height: 100vh;
    padding:0;
    margin:0;

}
</style>





