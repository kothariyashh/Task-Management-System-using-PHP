<?php
    include "./authentication.php";
    $id = $_GET['admin_id'];
    $sql = "UPDATE tbl_admin SET status = 0 WHERE user_id = $id";
    $result = $conn->query($sql);
    header("Location: ./admin-manage-user.php");
?>