<?php
require 'authentication.php';

$result = mysqli_query($conn1,"SELECT * FROM task_info");


   

echo "<table border='1' bgcolor='#fff' width='100%'>
<center>
<tr>
<th>Task Title</th>
<th>Task Description</th>
<th>Start Time</th>
<th>End Time</th>
<th>Status</th>
<th>Action</th>
</tr>";

while($row = mysqli_fetch_array($result))
  {

    echo"<tr>";
    // echo "<td>" .$serial; $serial++;  "</td>";
    echo "<td>" .$row['t_title'] ."</td>";
    echo "<td>" .$row['t_description'] ."</td>";
    echo "<td>" .$row['t_start_time'] ."</td>";
    echo "<td>" .$row['t_end_time'] ."</td>";
    echo "<td>" .$row['task_id'] ."</td>";
    // echo "<td>" .$row['task_id']; ."</td>";
    // echo "<td>" .$row['task_id']; ."</td>";
    


 echo "<td><a href='task-info.php?id=".$row['task_id']."'><button>pdf </button></a> ";


//  echo "<a  href='viewbill.php?id=".$row['id']."'>View Bill</td>";
  echo "</tr>";
  }
  
echo "</table>";
?></center>