-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2022 at 05:43 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(120) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_role` int(10) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_id`, `fullname`, `username`, `email`, `password`, `user_role`, `status`) VALUES
(1, 'Yash Kothari', 'Yash Kothari', 'kothariyash360@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1, 1),
(28, 'Charmi Gangani', 'charmi gangani', 'charmi.gangani109107@marwadiuniversity.ac.in', 'ead1b3c194df16847f7dabfe8859323d', 2, 1),
(27, 'Huzefa Dhankot', 'huzefa dhankot', 'huzefa.dhankot110473@marwadiuniversity.ac.in', 'f3d4029547640e414906ff771cc6302d', 2, 1),
(20, 'priyank sadhu', 'priyank sadhu', 'priyankvaisanav@gmail.com', '133f1b1d048a56c551fb62bd2f6b6543', 2, 1),
(29, 'Jill Patel', 'jill patel', 'jill.padariya109320@marwadiuniversity.ac.in', '5a5e50607cc5534975a0d3a1e0f50599', 2, 1),
(30, 'Kaushal Faldu', 'kaushal faldu', 'kaushalfaldu123@gmail.com', '8e4c672367bd65e577e9778bfb652f43', 2, 1),
(31, 'Akshit Chauhan', 'akshit chauhan', 'akshitchauhan987@gmail.com', '2f7f4cd7fccc660185f1508193b5c68c', 2, 1),
(32, 'Vasu Bhalodi', 'vasu bhalodi', 'vasubhalodi222@gmail.com', '8bee194c3d728acde93407b4b0719b6f', 2, 1),
(33, 'Kush Jadav', 'kush jadav', 'kushjadav13@gmail.com', '9a093d8914f3820aadf3bfc8362d08cc', 2, 1),
(34, 'Neel Agola', 'neel agola', 'neelagola27@gmail.com', '79cd378a7ec7eefc3eb6e2fd252f77e0', 2, 1),
(35, 'Janak Pariya', 'janak pariya', 'jankapariya777@gmail.com', '1511dc6aceadff5e10cd66ca6b0a58ac', 2, 1),
(36, 'Renish Surani', 'renish surani', 'renishsurani99@gmail.com', '808eeb359dad46c28d84a56908675dc6', 2, 1),
(37, 'Mann Desai', 'mann desai', 'manndesai08@gmail.com', '9f1bca728493031122bf2071730b5de8', 2, 1),
(38, 'Heet Zalavadiya', 'heet zalavadiya', 'heetzalavadiya24@gmail.com', '1d863d7bdb4d1e32c6559a5535d88663', 2, 1),
(41, 'Sarth Odedara', 'sarth odedara', 'sarth123@gmail.com', '5e1be343b4bd03810fa004e1090b1933', 2, 1),
(42, 'Tapan Khokhariya', 'tapan khokhariya', 'tapan1234@gmail.com', '55706b756860013ebe5d1f5f1cb7669a', 2, 1),
(45, 'jay', 'jaja', 'asxkn123@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 2, 1),
(46, 'nishit', 'wd', 'qdse123@gmail.com', '5768bbed686fb1078a80069fadb6ae81', 2, 0),
(47, 'bdhuqbw', 'kmdncwdc', 'wcq123@gmail.com', 'c99983d566ba4794ecd993e82bb697a6', 2, 0),
(48, 'dhairya satani', 'dhairya satani', 'dhairyasatani123@gmail.com', '61588a5d875ab9201f8391e31ba4a908', 2, 1),
(49, 'pratham pandya', 'pratham pandya', 'pratham123@gmail.com', 'd0be7b239be84fe7aedbbc0d1508ee72', 2, 1),
(50, 'darshan', 'darshan', 'darshan.padia114646@marwadiuniversity.ac.in', '3d4cf11b4474c78d0afe542498795af0', 2, 1),
(51, 'jatin', 'jatin', 'jatinpatel59967@gmail.com', 'ae010d5daefa9e63e3f31078a9946c31', 2, 1),
(52, 'devan patel', 'Devan', 'devan.patel.ict@gmail.com', 'aca6893ec3f0a23210ebadffbb9f23b4', 2, 1),
(53, 'mustafa', 'mustafa', 'mustafa.bharmal178@gmail.com', '5c0f785a91625ed552376ed0701a741a', 2, 1),
(54, 'arjun', 'arjun', 'arjun123@gmail.com', '451d3eb1573c7ebb70c08dfee9766509', 2, 1),
(55, 'ABHISHEK', 'abhishek', 'abhishek123@gmail.com', 'e5d1dfdc999e351aaf8861788e340f2c', 2, 1),
(56, 'nidhi', 'nidhi', 'nidhi123@gmail.com', '95c28f4c89aea555a463414c3d78e8e7', 2, 1),
(57, '123', '123', 'asd123@gmail.com', '6a2bdee0f6e81453ea9fbef3cca4a653', 2, 1),
(58, 'aniket patel', 'aniket patel', 'aniket12@gmail.com', '48ef889467e62ba74b52f1f09f51b586', 2, 1),
(59, 'krisha', 'krisha', 'krisha123@gmail.com', '6f451a76d34f2cefaf321fe69c4fed5a', 2, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
