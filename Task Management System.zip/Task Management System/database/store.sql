-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2022 at 05:43 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
CREATE TABLE IF NOT EXISTS `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `name`, `file`) VALUES
(11, 'Mann Desai', 'PS_Assignment_2.pdf'),
(10, 'Huzefa Dhankot', 'Q-1.pdf'),
(9, 'Akshit Chauhan', 'Mid 1_written.pdf'),
(5, 'Kaushal Faldu', 'Teaching Assessment Scheme.pdf'),
(6, 'Kaushal Faldu', 'Teaching Assessment Scheme.pdf'),
(7, 'Yash Kothari', 'Teaching Assessment Scheme.pdf'),
(8, 'Yash Kothari', 'Resume Shah Gopal PDF.pdf'),
(12, 'Kaushal Faldu', 'Functional Requirement.pdf'),
(13, 'Jill Patel', 'Functional Requirement.pdf'),
(14, 'pratham pandya', 'Webpage.pdf'),
(15, 'Yash Kothari', 'Project_based.pdf'),
(16, 'darshan', 'Online Task Management System.pdf'),
(17, 'jatin', 'DE-Ripple counter.pdf'),
(18, 'devan patel', 'OOP - Open Book Test -1.pdf'),
(19, 'mustafa', 'Fusion 360.pdf'),
(20, 'Yash Kothari', 'Teaching Assessment Scheme.pdf'),
(28, 'krisha', 'PS_EXAM.pdf'),
(29, 'krisha', 'PS_EXAM.pdf'),
(22, 'ABHISHEK', '39-P1 logical gates.pdf'),
(23, 'nidhi', 'OOP LHC-1.pdf'),
(24, 'Yash Kothari', 'Tutorial_Unit-2_A-converted-converted.pdf'),
(25, 'aniket patel', 'Syllabus_01CT0404.pdf'),
(26, 'Yash Kothari', 'case_study.pdf'),
(27, 'Yash Kothari', 'Assignment_2.pdf');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
