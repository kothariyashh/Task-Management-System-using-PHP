-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2022 at 05:43 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `task_info`
--

DROP TABLE IF EXISTS `task_info`;
CREATE TABLE IF NOT EXISTS `task_info` (
  `task_id` int(50) NOT NULL AUTO_INCREMENT,
  `t_title` varchar(120) NOT NULL,
  `t_description` text,
  `t_start_time` varchar(100) DEFAULT NULL,
  `t_end_time` varchar(100) DEFAULT NULL,
  `t_user_id` int(20) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 = incomplete, 1 = In progress, 2 = complete',
  `t_status` int(11) NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `task_info`
--

INSERT INTO `task_info` (`task_id`, `t_title`, `t_description`, `t_start_time`, `t_end_time`, `t_user_id`, `status`, `t_status`) VALUES
(56, 'DE', 'KMAP', '2022-05-03 11:06', '2022-05-04 11:06', 51, 1, 1),
(30, 'DBMS', 'lab work', '2022-03-14 12:00', '2022-04-01 12:00', 29, 2, 1),
(29, 'PS', 'standard deviation', '2022-02-28 12:00', '2022-04-01 12:00', 32, 0, 1),
(27, 'OS', 'open book test 1', '2022-03-30 22:00', '2022-03-30 23:00', 31, 1, 1),
(28, 'ADC', 'exp', '2022-03-22 00:00', '2022-03-31 12:00', 27, 1, 1),
(26, 'iwt', 'uml design', '2022-03-14 12:00', '2022-03-31 12:00', 30, 0, 1),
(31, 'MCI', 'AVR board', '2022-03-22 12:00', '2022-05-05 12:00', 33, 0, 1),
(32, 'PS', 'lab work', '2022-03-30 12:00', '2022-03-31 12:00', 32, 1, 1),
(34, 'ADC', 'exp10', '2022-03-30 12:00', '2022-03-31 12:00', 31, 0, 1),
(36, 'ADC', 'case study', '2022-03-28 12:00', '2022-03-31 12:00', 37, 0, 1),
(37, 'ADC', 'case study', '2022-03-28 12:00', '2022-03-31 12:00', 37, 2, 1),
(38, 'os', 'abcd', '2022-03-28 12:00', '2022-03-31 12:00', 35, 0, 1),
(45, 'OS', 'lab experminet', '2022-03-30 13:13', '2022-03-31 12:00', 29, 1, 1),
(49, 'IWT', 'demo', '2022-04-12 13:31', '2022-04-12 00:00', 30, 1, 1),
(48, 'MCI', 'lab manual', '2022-04-10 18:00', '2022-04-11 00:00', 30, 1, 1),
(52, 'sdgAGASFGEFB', 'Fwargaerg', '2022-05-19 15:40', '2022-05-19 15:43', 31, 2, 0),
(53, 'DBMS', 'Viva', '2022-05-02T21:31', '2022-05-03T23:33', 48, 0, 1),
(55, 'IWT', 'DEMO', '2022-05-03 10:55', '2022-05-04 10:55', 50, 2, 1),
(54, 'IWT', 'project', '2022-05-03 08:55', '2022-05-04 08:55', 49, 2, 1),
(57, 'JAVA', 'lab work', '2022-05-03 11:17', '2022-05-05 11:17', 52, 2, 1),
(58, 'EDCAD', 'drawing', '2022-05-03 11:28', '2022-05-04 11:28', 53, 2, 0),
(59, 'DE', 'lab manual', '2022-05-03 11:41', '2022-05-04 12:00', 54, 2, 0),
(63, '1234', 'dfghjkl', '2022-05-05 09:59', '2022-05-06 09:59', 59, 1, 1),
(60, 'DE', '123456', '2022-05-03 11:59', '2022-05-04 12:00', 55, 2, 1),
(61, 'OOP', 'lab experment', '2022-05-03 12:10', '2022-05-04 12:10', 56, 2, 1),
(62, 'IWT', 'project', '2022-05-03 12:35', '2022-05-04 12:35', 58, 0, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
