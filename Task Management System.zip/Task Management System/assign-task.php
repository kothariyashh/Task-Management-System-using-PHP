<?php

include("authentication.php"); 


$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['name'];
$security_key = $_SESSION['security_key'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}

$user_role = $_SESSION['user_role'];


if(isset($_GET['delete_task'])){
  $action_id = $_GET['task_id'];
  
  $sql = "DELETE FROM task_info WHERE task_id = :id";
  $sent_po = "task-info.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}

if(isset($_POST['add_task_post'])){
    $obj_admin->add_new_task($_POST);
}

$page_name="Task_Info";
include("sidebar.php");



?>



<HTML>
<body>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<center>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog add-category-modal">
    
   
      
      <div class="modal-content">
        <div class="modal-header">
          
          <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          <h1 class="modal-title text-center"style = "color:white;">Assign New Task</h1>
        </div>

        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              
              <form role="form" action="" method="post" autocomplete="off">
                <div class="form-horizontal">
                  <div class="form-group">
                    <label class="control-label col-sm-5"style = "color:white;" >Task Title :</label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Task Title" id="task_title" name="task_title" list="expense" class="form-control" id="default" required>
                    </div><br>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5"style = "color:white;">Task Description:</label><br>
                    <div class="col-sm-7">
                      <textarea name="task_description" id="task_description" placeholder="Text Deskcription" class="form-control" rows="4" cols="20"></textarea>
                    </div><br>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5"style = "color:white;">Start Time</label><br>
                    <div class="col-sm-7">
                      <input type="datetime-local" name="t_start_time" id="t_start_time" class="form-control">
                      <!-- <input type="time" name="t_end_time" id="t_end_time" class="form-control"> -->
                    </div><br>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5"style = "color:white;">End Time</label>
                    <div class="col-sm-7">
                      <input type="datetime-local" name="t_end_time" id="t_end_time" class="form-control">
                      <!-- <input type="time" name="t_end_time" id="t_end_time" class="form-control"> -->
                    </div><br>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-5"style = "color:white;">Assign To</label>
                    <div class="col-sm-7">
                      <?php 
                        $sql = "SELECT user_id, fullname FROM tbl_admin WHERE user_role = 2";
                        $info = $obj_admin->manage_all_info($sql);   
                      ?>
                      <select class="form-control" name="assign_to" id="aassign_to" required>
                        <option value="">Select Student...</option><br>

                        <?php while($row = $info->fetch(PDO::FETCH_ASSOC)){ ?>
                        <option value="<?php echo $row['user_id']; ?>"><?php echo $row['fullname']; ?></option>
                        <?php } ?>
                      </select><br>
                    </div>
                    <br>
                  </div>
                  <div class="form-group">
                  </div><br>
                  
                  <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-3">
                     <a href = "task-info.php"> <button type="submit" name="add_task_post" class="btn btn-success-custom"style = "background-color: grey;">Assign Task</button></a>
                    
                     <a href ="task-info.php"> <button type="submit" class="btn btn-danger-custom" data-dismiss="modal"style = "background-color: grey;">Cancel</button></a>
                    </div><br>
                        

                  </div>
                </div>
              </form>
                        </center>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</body>
</HTML>
<style>

#task_title {
  border: 2px solid red;
  padding: 10px;
  border-radius: 25px;
}


#task_description {
  border: 2px solid red;
  padding: 10px;
  border-radius: 25px;
}

#t_start_time {
  border: 2px solid red;
  padding: 10px;
  border-radius: 25px;
}

#t_end_time {
  border: 2px solid red;
  padding: 10px;
  border-radius: 25px;
}

#aassign_to {
  border: 2px solid red;
  padding: 10px;
  border-radius: 25px;
}



body {
  
  background-image: url("./CSS/img/123.jpg");
  
    background-size: cover;
    height: 100vh;
    padding:0;
    margin:0;

}
</style>