<?php
$servername='localhost';
$user_name='root';
$password='';
$db_name='tms';


$conn = new mysqli($servername, $user_name, $password, $db_name);


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// session_start();
$ran = random_int(000000,999999);
// echo "Connected successfully";
?>