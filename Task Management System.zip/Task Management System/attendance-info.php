<?php

require 'authentication.php'; 

$user_id = $_SESSION['admin_id'];
$user_name = $_SESSION['name'];
$security_key = $_SESSION['security_key'];
$user_role = $_SESSION['user_role'];
if ($user_id == NULL || $security_key == NULL) {
    header('Location: index.php');
}




if(isset($_GET['delete_attendance'])){
  $action_id = $_GET['aten_id'];
  
  // $sql = "UPDATE attendance_info set a_status = 0 WHERE aten_id = :id";
  $sql = "UPDATE FROM attendance_info set a _status = 0 WHERE  aten_id = :id";
  $sent_po = "attendance-info.php";
  $obj_admin->delete_data_by_this_method($sql,$action_id,$sent_po);
}


if(isset($_POST['add_punch_in'])){
   $info = $obj_admin->add_punch_in($_POST);
}

if(isset($_POST['add_punch_out'])){
    $obj_admin->add_punch_out($_POST);
}


$page_name="Attendance";
include("sidebar.php");

//$info = "Hello World";
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">




    <div class="row">
      <div class="col-md-12">
        <div class="well well-custom">
          <div class="row">
            <div class="col-md-8 ">
              <div class="btn-group">
                <?php 

                    //include("dbconnection.php");

                    $sql1 ="SELECT COUNT(*) as total FROM attendance_info";
                    $count = $conn->query($sql1);
                    $row = $count->fetch_assoc();
    
                    $page = 0;
                    $size = 10;
                    $totalpage = ceil($row['total']/$size);
                    if(isset($_POST['pg']))
                    {
                      $page = ($_POST['pg']-1)*$size;
                    }

                    // $sql = "SELECT * FROM tbl_admin WHERE user_role = 2 ORDER BY user_id DESC LIMIT $page,$size";
                                  
                  $sql = "SELECT * FROM attendance_info
                          WHERE atn_user_id = $user_id AND out_time IS NULL LIMIT $page,$size";
                
                


                  $info = $obj_admin->manage_all_info($sql);
                  $num_row = $info->rowCount();
                  if($num_row==0){
              ?>

                <div class="btn-group">
                  <form method="post" role="form" action="">
                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                    <button type="submit" name="add_punch_in" class="btn btn-primary btn-lg rounded" style = "background-color:grey;">CLOCK IN</button>
                  </form>

                
                  
                </div>

              <?php } ?>

              </div>
            </div>
            
          </div>

          <center><h3>Manage Atendance</h3>  </center>
          <div class="gap"></div>

          <div class="gap"></div>

          <div class="table-responsive">
          <center><table class="table table-codensed table-custom" border = "1" style = width:70%>
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th>Name</th>
                  <th>In Time</th>
                  <th>Out Time</th>
                  <th>Total Duration</th>
                  <th>Status</th>
                  <th>Details</th>
                  <!-- <?php if($user_role == 1){ ?>
              
                  <?php } ?> -->
                </tr>
              </thead>
              <tbody>

              <?php 
                // if($user_role == 1){
                //   $sql = "SELECT a.*, b.fullname 
                //   FROM attendance_info a
                //   LEFT JOIN tbl_admin b ON(a.atn_user_id = b.user_id)
                //   ORDER BY a.aten_id DESC LIMIT $page,$size";
                // }else{
                //   $sql = "SELECT a.*, b.fullname 
                //   FROM attendance_info a
                //   LEFT JOIN tbl_admin b ON(a.atn_user_id = b.user_id)
                //   WHERE atn_user_id = $user_id
                //   ORDER BY a.aten_id DESC LIMIT $page,$size";

                // }
                  
                  $sql = "SELECT * FROM attendance_info a LEFT JOIN tbl_admin b ON(a.atn_user_id = b.user_id) WHERE a.a_status = 1 ORDER BY a.aten_id DESC LIMIT $page,$size";

                  $info = $obj_admin->manage_all_info($sql);
                  $serial  = 1;
                  $num_row = $info->rowCount();
                  if($num_row==0){
                    echo '<tr><td colspan="7">No Data found</td></tr>';
                  }
                      while( $row = $info->fetch(PDO::FETCH_ASSOC) ){
              ?>
                <tr>
                  <td><?php echo $serial; $serial++; ?></td>
                  <td><?php echo $row['fullname']; ?></td>
                  <td><?php echo $row['in_time']; ?></td>
                  <td><?php echo $row['out_time']; ?></td>
                  <td><?php
                    if($row['total_duration'] == null){
                      $date = new DateTime('now', new DateTimeZone('Asia/Dhaka'));
                      $current_time = $date->format('d-m-Y H:i:s');

                      $dteStart = new DateTime($row['in_time']);
                      $dteEnd   = new DateTime($current_time);
                      $dteDiff  = $dteStart->diff($dteEnd);
                      echo $dteDiff->format("%H:%I:%S"); 
                    }else{
                      echo $row['total_duration'];
                    }
                    

                  ?></td>
                  <?php if($row['out_time'] == null){ ?>
                  <td>
                    <form method="post" role="form" action="">
                      <input type="hidden" name="punch_in_time" value="<?php echo $row['in_time']; ?>">
                      <input type="hidden" name="aten_id" value="<?php echo $row['aten_id']; ?>">
                      <button type="submit" name="add_punch_out" class="btn btn-danger btn-xs rounded"style = "background-color:grey;" >CLOCK OUT</button>
                    </form>
                  </td>
                <?php } ?>
                <?php if($user_role == 1){ ?>
                 <td>
                 <!-- onclick=" return check_delete();" -->
                  <!-- <a title="Delete" href="./delete_attendance-info?aten_id=<?php echo $row['aten_id'];?>" ><span class="glyphicon glyphicon-trash"><input type="button" name="delete_data" value="DELETE" style = "background-color:red;"></span></a> -->
                  <a href="./delete_attendance-info?aten_id=<?php echo $row['aten_id'];?>"><button style = "background-color:red;">DELETE</button></a>
                </td>
              <?php } ?>
                </tr>
                <?php } ?>
                
              </tbody>
                
            </table>
                </center>
          </div>
        </div>
      </div>
    </div>

<br>
<?php




echo "<center><table border=0><tr>";
for($i=1;$i<=$totalpage;$i++){
  echo "<td>
    <form method='post' action='./attendance-info.php'>
      <input type='hidden' value=$i name='pg'></input>
      <input type='submit' name='submit' value='$i'>
    </form>
  </td>";
}
echo "<tr></table></center>";


?>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<style>
body {

  
  background-image: url("./CSS/img/4.jpg");  

  font-family: "Times New Roman", Times, serif;

    background-size: cover;
    
    
    
    height: 100vh;
    padding:0;
    margin:0;

}
</style>