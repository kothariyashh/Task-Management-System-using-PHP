<div>
    <form action="./download.php" method="POST">
        <button name="report">Generate </button>
</form>
</div>