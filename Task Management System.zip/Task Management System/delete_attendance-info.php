<?php
    require 'authentication.php'; 

    // if(isset($_POST['delete_data'])){
        $id = $_GET['aten_id'];
        $sql = "UPDATE attendance_info SET a_status = 0 WHERE aten_id = $id";
        $result2 = $conn->query($sql);
        header("Location: ./attendance-info.php");
    // }
    // else{
        // echo "error";
    // }